# -*- coding: utf-8 -*-

from django.conf import settings
from django.db import models
from django_extensions.db.fields import CreationDateTimeField
from project.models import Project


class Requirement(models.Model):

    created = CreationDateTimeField("创建的时间")
    title = models.CharField(max_length=255)
    content = models.TextField()
    state = models.CharField(max_length=255)
    creator = models.ForeignKey(settings.AUTH_USER_MODEL)
    project = models.ManyToManyField(Project)