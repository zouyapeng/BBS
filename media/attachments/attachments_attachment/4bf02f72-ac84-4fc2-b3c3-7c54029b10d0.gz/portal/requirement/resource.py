# -*- coding: utf-8 -*-
from django.conf.urls import url
from tastypie.authentication import SessionAuthentication
from tastypie.authorization import DjangoAuthorization
from tastypie.resources import ModelResource
from tastypie.utils import trailing_slash
from .models import Requirement


class RequirementResource(ModelResource):

    class Meta:
        queryset = Requirement.objects.all()
        resource_name = 'requirement'
        authentication = SessionAuthentication()
        authorization = DjangoAuthorization()
        list_allowed_methods = []
        detail_allowed_methods = []
        always_return_data = True
