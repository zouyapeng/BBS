from django.conf.urls import include, url
from django.contrib import admin
from tastypie.api import Api
from .resource import ProjectResource

api = Api('project')
api.register(ProjectResource())

urlpatterns = [

]
