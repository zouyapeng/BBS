# -*- coding: utf-8 -*-
from django.conf import settings
from django.db import models
from django_extensions.db.fields import CreationDateTimeField
from account.models import User


class Project(models.Model):
    name = models.CharField('项目名称', max_length=255)
    description = models.TextField('项目描述')
    project_type = models.CharField(max_length=255)
    gitrepo = models.TextField()
    created = CreationDateTimeField("创建的时间")
    owner = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name="owner_member", through='ProjectOwner')
    member = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name="project_member",
                                    through='ProjectMember')


class ProjectOwner(models.Model):
    project = models.ForeignKey(Project)
    owner = models.ForeignKey(settings.AUTH_USER_MODEL)


class ProjectMember(models.Model):
    project = models.ForeignKey(Project)
    member = models.ForeignKey(settings.AUTH_USER_MODEL)