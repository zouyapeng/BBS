from django.conf.urls import include, url
from django.contrib import admin
from django.views.generic import TemplateView
from project import urls as project_urls
from requirement import urls as requirement_urls
from task import urls as task_urls

urlpatterns = [
    # url(r'^$', 'portal.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^api/', include(project_urls.api.urls
                          +requirement_urls.api.urls
                          +task_urls.api.urls
    )),
    url(r'^admin/', include(admin.site.urls)),
]+[
    url(r'^$', TemplateView.as_view(template_name='home.html'))
]
