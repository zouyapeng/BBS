# -*- coding: utf-8 -*-

from django.conf import settings
from django.db import models
from django_extensions.db.fields import CreationDateTimeField
from project.models import Project


class Task(models.Model):

    created = CreationDateTimeField("创建的时间")
    content = models.TextField()
    executor = models.ManyToManyField(settings.AUTH_USER_MODEL)
    project = models.ManyToManyField(Project)