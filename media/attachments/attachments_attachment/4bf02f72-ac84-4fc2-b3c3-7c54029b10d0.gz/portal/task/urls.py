from django.conf.urls import include, url
from django.contrib import admin
from tastypie.api import Api
from .resource import TaskResource

api = Api('task')
api.register(TaskResource())

urlpatterns = [

]
